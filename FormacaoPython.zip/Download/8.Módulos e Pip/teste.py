PI = 3.1415

class Teste:
  def __init__(self):
    print('Classe teste')


def MyFunc(num):
  print(num)