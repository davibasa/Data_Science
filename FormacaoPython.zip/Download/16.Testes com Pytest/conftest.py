import pytest

@pytest.fixture
def retorna_valor():
  return 10