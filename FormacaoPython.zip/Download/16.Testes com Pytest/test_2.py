import pytest


def test_impar():
  assert 5 % 2 == 1